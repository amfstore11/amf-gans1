# amf-gans1
ari terganteng di duniaaaaa
